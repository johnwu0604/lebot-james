# DPM Group 11 Final Project

A soccer/basketball playing robot built using the Minstorm Lejos EV3 Kit
package gui.defaults;

import java.util.ArrayList;

public class DPMEntryItemList extends ArrayList<DPMEntryItem> {
	//TODOInclude fast searching method based on key? Switch to HashMap implementation?
}
